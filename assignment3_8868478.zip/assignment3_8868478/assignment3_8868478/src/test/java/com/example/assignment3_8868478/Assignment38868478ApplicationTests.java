package com.example.assignment3_8868478;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assignment38868478ApplicationTests {

	@Test
	void contextLoads() {
	}

}
