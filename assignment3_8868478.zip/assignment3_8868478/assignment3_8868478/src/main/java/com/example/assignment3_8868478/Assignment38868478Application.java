package com.example.assignment3_8868478;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment38868478Application {

	public static void main(String[] args) {
		SpringApplication.run(Assignment38868478Application.class, args);
	}

}
