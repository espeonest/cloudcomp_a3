package com.example.assignment3_8868478.service;

import org.springframework.stereotype.Service;

@Service
public class ShoesService {



}
