package com.example.assignment3_8868478.controller;

import com.example.assignment3_8868478.model.Shoes;
import com.example.assignment3_8868478.repository.ShoesRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ShoesController {
    private final ShoesRepository repository;

    public ShoesController(ShoesRepository repository) {
        this.repository = repository;
    }

    // GET /shoes
    @GetMapping("/shoes")
    public List<Shoes> getAllShoes() {
        return repository.findAll();
    }

    // GET shoe by ID
    @GetMapping("shoes/{shoeID}")
    public Shoes getShoeById(@PathVariable int shoeID) {
        return repository.findById(shoeID);
    }

    @PostMapping("/shoes")
    public Shoes addNewShoe(@RequestBody Shoes shoe) {
       repository.save(shoe);
        return shoe; // return the created object
    }






}
